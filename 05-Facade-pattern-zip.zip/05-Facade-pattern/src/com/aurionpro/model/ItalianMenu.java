package com.aurionpro.model;

public class ItalianMenu implements IMenu {

	@Override
	public void displayMenu() {
		// TODO Auto-generated method stub
		System.out.println("Italian Dal Chawal");

	}

}
