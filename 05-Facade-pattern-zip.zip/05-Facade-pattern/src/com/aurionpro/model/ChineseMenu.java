package com.aurionpro.model;

public class ChineseMenu implements IMenu {

	@Override
	public void displayMenu() {
		// TODO Auto-generated method stub
		System.out.println("Chinese Dal-chawal");
		
	}

}
