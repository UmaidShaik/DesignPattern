package com.aurionpro.model;

public class IndianMenu implements IMenu {

	@Override
	public void displayMenu() {
		// TODO Auto-generated method stub
		System.out.println("Dal Chawal");

	}

}
