package com.aurionpro.model;

public interface IHotel {
	
	public IMenu getMenu();

}
