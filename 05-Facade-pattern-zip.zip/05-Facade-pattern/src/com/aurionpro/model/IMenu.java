package com.aurionpro.model;

public interface IMenu {

	public void displayMenu();
}
