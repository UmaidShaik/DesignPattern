package com.aurionpro.model;

public interface IEmployee {
	
	public void showEmployeeDetails();

}
