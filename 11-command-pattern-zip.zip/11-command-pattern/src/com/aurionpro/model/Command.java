package com.aurionpro.model;

public interface Command {
void execute();
}
